#!/bin/sh
aclocal14
automake14
autoheader213
autoconf213
