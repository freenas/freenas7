/*-
 * Copyright (c) 2004, Sam Hopkins <sah@coraid.com>
 * Copyright (c) 2006, Stacey D. Son <sds@son.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <sys/cdefs.h>
__FBSDID("$FreeBSD: src/sys/dev/aoe/aoenet.c,v 1.23.2.5 2004/09/22 16:50:41 ?? Exp $");

/*
 * aoenet.c
 * Ethernet portion of AoE driver
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/mbuf.h>
#include <sys/sysctl.h>
#include <sys/kernel.h>
#include <sys/socket.h>

#include <net/bpf.h>
#include <net/ethernet.h>
#include <net/if.h>
#include <net/if_var.h>
#include <net/if_types.h>
#include <net/if_arp.h>
#include <net/netisr.h>

#include <dev/aoe/aoe.h>

/*
 * FORCE_NETWORK_HOOK is defined to support kernels that have not been patched
 * to recognize AoE packets.
 */ 
#ifdef FORCE_NETWORK_HOOK
static const u_char etherbroadcastaddr[ETHER_ADDR_LEN] =
                         { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static void (*old_ether_input)(struct ifnet *, struct mbuf *) = NULL;
#endif
extern boolean_t aoe_exiting;
struct ifqueue aoeintrq;

static char *aoe_errlist[] =
{
	"no such error",
	"unrecognized command code",
	"bad argument parameter",
	"device unavailable",
	"config string present",
	"unsupported version"
};

#define NECODES (sizeof(aoe_errlist) /  sizeof(char *) - 1)
#if (__FreeBSD_version < 600000)
#define IFPADDR(ifp) (((struct arpcom *) (ifp))->ac_enaddr)
#else
#define IFPADDR(ifp) IFP2ENADDR(ifp) 
#endif
#define IFLISTSZ 1024

static char aoe_iflist[IFLISTSZ];

static int sysctl_aoe_iflist(SYSCTL_HANDLER_ARGS);

SYSCTL_DECL(_net_aoe);
SYSCTL_OID(_net_aoe, OID_AUTO, iflist, CTLTYPE_STRING|CTLFLAG_RW, 
	aoe_iflist, IFLISTSZ - 1, sysctl_aoe_iflist, "A", 
	"Space separated list of interfaces valid for AoE"); 

#if (__FreeBSD_version < 600000)
/* FreeBSD 5.X doesn't include strspn()... */
#include <sys/limits.h>
#define IDX(c)  ((u_char)(c) / LONG_BIT)
#define BIT(c)  ((u_long)1 << ((u_char)(c) % LONG_BIT))
 
static size_t
strspn(const char *s, const char *charset)
{
       /*
        * NB: idx and bit are temporaries whose use causes gcc 3.4.2 to
        * generate better code.  Without them, gcc gets a little confused.
        */
       const char *s1;
       u_long bit;
       u_long tbl[(UCHAR_MAX + 1) / LONG_BIT];
       int idx;
 
       if(*s == '\0')
               return (0);
 
#if LONG_BIT == 64      /* always better to unroll on 64-bit architectures */
       tbl[3] = tbl[2] = tbl[1] = tbl[0] = 0;
#else
       for (idx = 0; idx < sizeof(tbl) / sizeof(tbl[0]); idx++)
               tbl[idx] = 0;
#endif
       for (; *charset != '\0'; charset++) {
               idx = IDX(*charset);
               bit = BIT(*charset);
               tbl[idx] |= bit;
       }

       for(s1 = s; ; s1++) {
               idx = IDX(*s1);
               bit = BIT(*s1);
               if ((tbl[idx] & bit) == 0)
                       break;
       }
       return (s1 - s);
}
#endif /* __FreeBSD_version < 600000 */
 

/* aoe_strcspn -- span the complement of a string */
static size_t
aoe_strcspn(const char *s, const char *reject)
{
        const char *p;
        const char *r;
        size_t count = 0;

        for (p = s; *p != '\0'; ++p) {
                for (r = reject; *r != '\0'; ++r) {
                        if (*p == *r)
                                return (count);
                }
                ++count;
        }

        return (count);
}

static boolean_t
is_aoe_netif(struct ifnet *ifp)
{
        register char *p, *q;
        register int len;

        switch (ifp->if_data.ifi_type) {
        default:
                return (FALSE);
        case IFT_ETHER:
        case IFT_FASTETHER:
        case IFT_GIGABITETHERNET:
                break;
        }

        p = aoe_iflist + strspn(aoe_iflist, WHITESPACE);
        for (; *p; p = q + strspn(q, WHITESPACE)) {
                q = p + aoe_strcspn(p, WHITESPACE);
                if (q != p)
                        len = q - p;
                else
                        len = strlen(p); /* last token in aoe_iflist */

                if (strlen(ifp->if_xname) == len && !strncmp(ifp->if_xname, p, len))
                        return (TRUE);
                if (q == p)
                        break;
        }

        return (FALSE);
}


/* 
 * a dummy "free" function for mbuf ext buffer 
 */
static void
nilfn(void *a, void *b)
{
}

/* Create a mbuf chain and point to our data section(s). */
static struct mbuf *
frame_mbufinit(struct frame *f)
{
        struct mbuf *m;

	if ((m = m_gethdr(M_DONTWAIT, MT_DATA)) == NULL)
		return (NULL);
	m->m_len = AOEHDRSZ;
	m->m_pkthdr.len = f->f_mlen;
	MH_ALIGN(m, AOEHDRSZ);
	bcopy(f->f_hdr, m->m_data, AOEHDRSZ);
	m->m_pkthdr.rcvif = NULL;
	m->m_next = NULL;
	
        if (f->f_data) {   
                struct mbuf *m1;
                u_int len;

                len = f->f_mlen - AOEHDRSZ;
		if ((m1 = m_get(M_DONTWAIT, MT_DATA)) == NULL) {
			m_freem(m);
			return (NULL);
		}
		m->m_next = m1;

		m1->m_ext.ref_cnt = NULL;
		MEXTADD(m1, f->f_data, len, nilfn, 
			NULL, 0, EXT_NET_DRV);
		m1->m_len = len;
		m1->m_next = NULL;
        }

        return (m);
}

int
aoenet_xmitframe(struct aoedev *d, struct frame *f)
{
	struct mbuf *m;

	m = frame_mbufinit(f);
	if (m == NULL) 
		return (ENOMEM);	

	return (ether_output_frame(d->ad_ifp, m));
}

void
aoenet_xmitbcast(u_short aoemajor, u_char aoeminor)
{
	struct aoe_hdr *h;
	struct aoe_cfghdr *ch;
	struct mbuf *m, *m0;
	struct ifnet *ifp;
	
	m0 = m_gethdr(M_NOWAIT, MT_DATA);
	if (m0 == NULL) {
		IPRINTK("mget failure\n");
		return;
	}
	m0->m_len = sizeof(*h) + sizeof(*ch);
	m0->m_pkthdr.len = m0->m_len;
	MH_ALIGN(m0, m0->m_len);
	h = mtod(m0, struct aoe_hdr *);
	ch = (struct aoe_cfghdr *) (h+1);
	bzero(h, sizeof(*h) + sizeof(*ch));
	m0->m_flags |= M_BCAST;

	memset(h->ah_dst, 0xff, sizeof(h->ah_dst));
	h->ah_type = htons(ETHERTYPE_AOE);
	h->ah_verfl = AOE_HVER;
	h->ah_major = htons(aoemajor);
	h->ah_minor = aoeminor;
	h->ah_cmd = AOECMD_CFG;

	IFNET_RLOCK();
	TAILQ_FOREACH(ifp, &ifnet, if_link) {
		if (!is_aoe_netif(ifp))
			continue;
		memcpy(h->ah_src, IFPADDR(ifp), sizeof(h->ah_src));
		m = m_copypacket(m0, M_DONTWAIT);
		if (m == NULL) {
			IPRINTK("m_copypacket failure\n");
			continue;
		}
		ether_output_frame(ifp, m);
	}
	IFNET_RUNLOCK();

	m_freem(m0);
}

u_char *
aoenet_enaddr(struct ifnet *ifp)
{
	return (IFPADDR(ifp));
}

u_int
aoenet_maxsize(struct ifnet *ifp)
{
	/* max payload size of packet based on interface mtu setting */
	return ((ifp->if_data.ifi_mtu - AOEHDRSZ) & ~(DEV_BSIZE - 1));
}


/* (1) The tag high bit is not permitted to be set for our responses.  */
static void
aoeintr(struct mbuf *m)
{
	struct aoe_hdr *h;
	uint32_t n;

	if (aoe_exiting) {
		m_freem(m);
		return;
	}


	do {
#ifndef FORCE_NETWORK_HOOK
		if (!is_aoe_netif(m->m_pkthdr.rcvif))
			break;
#endif 
	
		h = mtod(m, struct aoe_hdr *);
		n = ntohl(h->ah_tag);
		if ((h->ah_verfl & AOEFL_RSP) == 0 || (n & 1<<31)) /* (1) */
			break;
		if (h->ah_verfl & AOEFL_ERR) {
			n = h->ah_err;
			if (n > NECODES)
				n = 0;
			IPRINTK("error packet from %d.%d; ecode=%d '%s'\n",
				ntohs(h->ah_major), h->ah_minor, h->ah_err, aoe_errlist[n]);
			break;
		}
	
		switch (h->ah_cmd) {
		case AOECMD_ATA:
			aoecmd_ata_rsp(m);
			break;
		case AOECMD_CFG:
			aoecmd_cfg_rsp(m);
			break;
		default:
			IPRINTK("unknown cmd %d\n", h->ah_cmd);
		}
	} while (0);

	m_freem(m);
}

#ifdef FORCE_NETWORK_HOOK
static void
aoe_ether_input(struct ifnet *ifp, struct mbuf *m)
{
        struct ether_header *eh;
        u_short etype;
                
        /*
         * Do consistency checks to verify assumptions
         * made by code past this point.
         */
        if ((m->m_flags & M_PKTHDR) == 0) {
                if_printf(ifp, "discard frame w/o packet header\n");
                ifp->if_ierrors++;
                m_freem(m);
                return;
	}
	
        if (m->m_len < ETHER_HDR_LEN) {
                if_printf(ifp, "discard frame w/o leading ethernet "
                                "header (len %u pkt len %u)\n",
                                m->m_len, m->m_pkthdr.len);
                ifp->if_ierrors++;
                m_freem(m);
                return;
        }
        eh = mtod(m, struct ether_header *);
        etype = ntohs(eh->ether_type);
	if (etype != ETHERTYPE_AOE) {
		(*old_ether_input)(ifp, m);
		return;
	}
        if (m->m_pkthdr.len >
            ETHER_MAX_FRAME(ifp, etype, m->m_flags & M_HASFCS)) {
                if_printf(ifp, "discard oversize frame "
                                "(ether type %x flags %x len %u > max %lu)\n",
                                etype, m->m_flags, m->m_pkthdr.len,
                                ETHER_MAX_FRAME(ifp, etype,
                                                m->m_flags & M_HASFCS));
                ifp->if_ierrors++;
                m_freem(m);
                return;
        }
        if (m->m_pkthdr.rcvif == NULL) {
                if_printf(ifp, "discard frame w/o interface pointer\n");
                ifp->if_ierrors++;
                m_freem(m);
                return;
	}
        /*
         * Give bpf a chance at the AoE packet.
         */
       	BPF_MTAP(ifp, m);

        if (ifp->if_flags & IFF_MONITOR) {
                /*
                 * Interface marked for monitoring; discard packet.
                 */
                m_freem(m);
                return;
        }

        /* If the CRC is still on the packet, trim it off. */
        if (m->m_flags & M_HASFCS) {
                m_adj(m, -ETHER_CRC_LEN);
                m->m_flags &= ~M_HASFCS;
        }

        ifp->if_ibytes += m->m_pkthdr.len;

        if (ETHER_IS_MULTICAST(eh->ether_dhost)) {
                if (bcmp(etherbroadcastaddr, eh->ether_dhost,
                    sizeof(etherbroadcastaddr)) == 0)
                        m->m_flags |= M_BCAST;
                else
                        m->m_flags |= M_MCAST;
        }
        if (m->m_flags & (M_BCAST|M_MCAST))
                ifp->if_imcasts++;

	aoeintr(m); 
	/* netisr_dispatch(NETISR_AOE, m); */
}
#endif /* FORCE_NETWORK_HOOK */

static int
sysctl_aoe_iflist(SYSCTL_HANDLER_ARGS)
{
	int error;
#ifdef FORCE_NETWORK_HOOK
	struct ifnet *ifp;
#endif

	error = sysctl_handle_string(oidp, arg1, arg2, req);

#ifdef FORCE_NETWORK_HOOK
	IFNET_RLOCK();
	TAILQ_FOREACH(ifp, &ifnet, if_link) {
		if (!is_aoe_netif(ifp)) {
			if (ifp->if_input == aoe_ether_input)
				ifp->if_input = old_ether_input;
			continue;
		}
		if (ifp->if_input !=  aoe_ether_input) 
			ifp->if_input = aoe_ether_input;
		
	}
	IFNET_RUNLOCK();
#endif /* FORCE_NETWORK_HOOK */

	aoecmd_cfg(0xffff, 0xff);
	
	return (error);
}

void
aoenet_init(void)
{
#ifdef FORCE_NETWORK_HOOK
	struct ifnet *ifp;

	IFNET_RLOCK();
	TAILQ_FOREACH(ifp, &ifnet, if_link) {
        	switch (ifp->if_data.ifi_type) {
        	case IFT_ETHER:
        	case IFT_FASTETHER:
        	case IFT_GIGABITETHERNET:
                	break;
        	default:
               		continue; 
        	}
		if (old_ether_input == NULL) 
			old_ether_input = ifp->if_input;
		else if (old_ether_input != ifp->if_input)
			IPRINTK("ifp->if_input != ether_input\n");
	}
	IFNET_RUNLOCK();
#else 
	aoeintrq.ifq_maxlen = IFQ_MAXLEN;
	mtx_init(&aoeintrq.ifq_mtx, "aoe_inq", NULL, MTX_DEF);
	netisr_register(NETISR_AOE, aoeintr, &aoeintrq, NETISR_MPSAFE);
#endif  /* ! FORCE_NETWORK_HOOK */
}

void
aoenet_exit(void)
{
#ifdef FORCE_NETWORK_HOOK
	struct ifnet *ifp;

	IFNET_RLOCK();
	TAILQ_FOREACH(ifp, &ifnet, if_link) {
        	switch (ifp->if_data.ifi_type) {
        	case IFT_ETHER:
        	case IFT_FASTETHER:
        	case IFT_GIGABITETHERNET:
                	break;
        	default:
               		continue; 
        	}
		if (ifp->if_input == aoe_ether_input)
			ifp->if_input = old_ether_input;
	}
	IFNET_RUNLOCK();
#else 
	netisr_unregister(NETISR_AOE);
	mtx_destroy(&aoeintrq.ifq_mtx);
#endif  /* ! FORCE_NETWORK_HOOK */
}
