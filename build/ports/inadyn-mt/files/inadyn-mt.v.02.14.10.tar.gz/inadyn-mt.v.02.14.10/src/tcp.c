/*
Copyright (C) 2003-2004 Narcis Ilisei
Modifications by Bryan Hoover (bhoover@wecs.com)
Copyright (C) 2009 Bryan Hoover (bhoover@wecs.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
	Dyn Dns update main implementation file 
	Author: narcis Ilisei
	Date: May 2003

	History:
        Sept. 2009
	  - Non-blocking socket create, and connect
	  - Windows socket layer shutdown per startup
*/
#define MODULE_TAG      "TCP: "  

#include <stdlib.h>
#include <string.h>

#ifdef USE_THREADS
#ifndef _WIN32
#include <pthread.h>
#include <signal.h>
#include <semaphore.h>
#else
#include <windows.h>
#include <winbase.h>
#include <process.h>
#endif
#endif

#include "tcp.h"
#include "safe_mem.h"
#include "debug_if.h"
/*
	 basic resource allocations for the tcp object
*/
RC_TYPE tcp_construct(TCP_SOCKET *p_self)
{
	RC_TYPE rc;

	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	rc = ip_construct(&p_self->super);	
	if (rc != RC_OK)
	{
		return rc;
	}

	/*reset its part of the struct (skip IP part)*/
	memset( ((char*)p_self + sizeof(p_self->super)) , 0, sizeof(*p_self) - sizeof(p_self->super));
	p_self->initialized = FALSE;
	
	return RC_OK;
}

/*
	Resource free.
*/	
RC_TYPE tcp_destruct(TCP_SOCKET *p_self)
{
	if (p_self == NULL)
	{
		return RC_OK;
	}

	if (p_self->initialized == TRUE)
	{
		tcp_shutdown(p_self);
	}
		
	return ip_destruct(&p_self->super);
}

static RC_TYPE local_set_params(TCP_SOCKET *p_self)
{
	int timeout;
	/*set default TCP specififc params*/
	tcp_get_remote_timeout(p_self, &timeout);

	if (timeout == 0)
	{
		tcp_set_remote_timeout(p_self, TCP_DEFAULT_TIMEOUT);
	}
	return RC_OK;
}

RC_TYPE tcp_create_socket(TCP_SOCKET *p_self)
{
	RC_TYPE	rc;


	do {

		local_set_params(p_self);

		/*call the super*/
		rc = ip_initialize(&p_self->super);
		if (rc != RC_OK)
		{
			break;
		}

		/*local object initalizations -- and in case async, check if already init*/
		if (!(p_self->super.type == TYPE_TCP))
		{
			rc = RC_IP_BAD_PARAMETER;
		}
		else {

			if (!(p_self->super.socket)) {

				p_self->super.socket = socket(AF_INET,SOCK_STREAM,0);
				if (p_self->super.socket == -1)
				{
					rc = RC_IP_SOCKET_CREATE_ERROR;
					break;
				}
			}
		}

		/* set timeouts */
		setsockopt(p_self->super.socket,SOL_SOCKET,SO_RCVTIMEO,
				(char*)&p_self->super.timeout,sizeof(p_self->super.timeout));
		setsockopt(p_self->super.socket,SOL_SOCKET,SO_SNDTIMEO,
				(char*)&p_self->super.timeout,sizeof(p_self->super.timeout));
	} 
	while(0);

	return rc;
}

#ifdef USE_THREADS

#ifdef _WIN32
static int get_mutex(void **mutex)
#else
static int get_mutex(pthread_mutex_t **mutex)
#endif
{

#ifndef _WIN32

	if (!(*mutex))
		return EINVAL;

	return pthread_mutex_lock(*mutex);
#else
	return (!(WaitForSingleObject(*mutex,INFINITE)==WAIT_OBJECT_0));
#endif
}

#ifdef _WIN32
static int release_mutex(void **mutex)
#else
static int release_mutex(pthread_mutex_t **mutex)
#endif
{
#ifndef _WIN32

	if (!(*mutex))
		return EINVAL;

	return pthread_mutex_unlock(*mutex);
#else
	return (!(ReleaseMutex(*mutex)));
#endif
}

#ifdef _WIN32
static int signal_sem(void **sem)
#else
static int signal_sem(sem_t *sem)
#endif
{
#ifndef _WIN32

	if (!(sem))
		return EINVAL;

	return sem_post(sem);
#else

	return (!(ReleaseSemaphore(*sem,1,NULL)));
#endif
}

#ifdef _WIN32
static int wait_sem(void **sem)
#else
static int wait_sem(sem_t *sem)
#endif
{
#ifndef _WIN32

	if (!(sem))
		return EINVAL;

	return sem_wait(sem);
#else

	return (!(WaitForSingleObject(*sem,INFINITE)==WAIT_OBJECT_0));
#endif
}

static RC_TYPE do_connect(TCP_SOCKET *p_self)
{
	RC_TYPE	rc=RC_IP_SOCKET_CREATE_ERROR;


	if (!(p_self)) {

		DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "p_self null in do_connect...\n"));

		return rc;
	}
		

	if (!(p_self->super.socket)) {

		DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "p_self->super.socket null in do_connect...\n"));

		return rc;
	}


	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "calling socket function, connect, in do_connect...\n"));


	if (!(connect(p_self->super.socket,(struct sockaddr *)&p_self->super.remote_addr,sizeof(p_self->super.remote_addr))))

		rc=RC_OK;


	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "do_connect, returned from socket function, connect...\n"));


	return rc;
}

static void destroy_connect_data(CONNECT_THREAD_DATA **p_data)
{
#ifndef _WIN32
	pthread_mutex_t	tmp_m;
#endif

	free((*p_data)->p_self);

#ifdef _WIN32
	CloseHandle((*p_data)->t_data_mutex);
#else
	get_mutex(&(*p_data)->t_data_mutex);

	memcpy(&tmp_m,(*p_data)->t_data_mutex,sizeof(pthread_mutex_t));

	free((*p_data)->t_data_mutex);
	(*p_data)->t_data_mutex=NULL;

	pthread_mutex_unlock(&tmp_m);
	pthread_mutex_destroy(&tmp_m);
#endif
	
	free(*p_data);
	*p_data=NULL;
}

static CONNECT_THREAD_DATA *create_connect_data(void *p_data)
{
	CONNECT_THREAD_DATA	*p_thread_data=NULL;


	p_thread_data=safe_malloc(sizeof(CONNECT_THREAD_DATA));


	if (!(p_thread_data)) {

		DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "failed allocating connect thread data in create_connect_data...\n"));

		return NULL;
	}
	else {

		memset(p_thread_data,0,sizeof(CONNECT_THREAD_DATA));
		p_thread_data->p_self=p_data;
		p_thread_data->rc=RC_IP_CONNECT_FAILED;
#ifndef _WIN32
		p_thread_data->t_data_mutex=safe_malloc(sizeof(pthread_mutex_t));
		pthread_mutex_init(p_thread_data->t_data_mutex,NULL);
		sem_init(&p_thread_data->t_data_sem,0,0);
#else
		p_thread_data->t_data_mutex=CreateMutex(NULL,0,NULL);
		p_thread_data->t_data_sem=CreateSemaphore(NULL,0,1,NULL);
#endif

		return p_thread_data;
	}
}

#ifndef _WIN32
static void *connect_thread(void *p_data)
#else
static void connect_thread(void *p_data)
#endif
{
	CONNECT_THREAD_DATA	*p_ct_data=(CONNECT_THREAD_DATA *) p_data;
	TCP_SOCKET			*p_self;


	if (!(p_ct_data)) {

		DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "p_ct_data null in connect_thread...\n"));

#ifdef _WIN32

		return;
#else
		return NULL;
#endif
	}

#ifndef _WIN32

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,NULL);
#endif

	p_self=p_ct_data->p_self;

	if (!(p_self)) {

		DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "p_ct_data->p_self null in connect_thread...\n"));

		p_ct_data->rc=RC_INVALID_POINTER;
	}
	else {

		DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "attempting to create socket in connect_thread...\n"));
		
		if (!(tcp_create_socket(p_self)==RC_OK)) {

			DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "failed socket create in connect_thread...\n"));
		}
		else {

			DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "calling do_connect from connect_thread\n"));


			p_ct_data->rc=do_connect(p_self);

		
			DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "connect thread returned from connect, connected: %d\n",(p_ct_data->rc==RC_OK)));
		}
	}

	p_ct_data->is_thread_exit=1;

	get_mutex(&p_ct_data->t_data_mutex);
	signal_sem(&p_ct_data->t_data_sem);


	if (!(p_ct_data->is_parent_exit)) {

		release_mutex(&p_ct_data->t_data_mutex);
	}
	else {

		/*we're orphaned, and in case program still running, deallocate what can*/

		release_mutex(&p_ct_data->t_data_mutex);

		DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "connect thread destroying parent data...\n"));

		destroy_connect_data(&p_ct_data);
	}

	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "connect thread exiting...\n"));

#ifdef _WIN32
	_endthread();
#else
	pthread_exit(p_ct_data);

	/*compiler complaints (pthread_exit does not return)*/
	return p_ct_data;
#endif

}

#endif

/* 
	Sets up the object.

	- ...
*/
RC_TYPE tcp_initialize(TCP_SOCKET *p_self)
{
	RC_TYPE rc;
	do
	{
		if (!(RC_OK==(rc=tcp_create_socket(p_self))))

			break;

		/*connect*/
		if (0 != connect(p_self->super.socket,
				(struct sockaddr *)&p_self->super.remote_addr,sizeof(p_self->super.remote_addr)))
		{
			rc = RC_IP_CONNECT_FAILED;
			break;
		}

	}
	while(0);

	if (rc != RC_OK)
	{
		tcp_shutdown(p_self);		
	}
	else
	{
		p_self->initialized = TRUE;
	}
			
	return rc;
}
/* 
	Disconnect and some other clean up.
*/
RC_TYPE tcp_shutdown(TCP_SOCKET *p_self)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (!p_self->super.socket)
	{
		return RC_OK;
	}

	p_self->initialized = FALSE;

	return ip_shutdown(&p_self->super);
}


/* send data*/
RC_TYPE tcp_send(TCP_SOCKET *p_self, const char *p_buf, int len)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (!p_self->initialized)
	{
		return RC_TCP_OBJECT_NOT_INITIALIZED;
	}
	return ip_send(&p_self->super, p_buf, len);
}

/* receive data*/
RC_TYPE tcp_recv(TCP_SOCKET *p_self,char *p_buf, int max_recv_len, int *p_recv_len)
{
	if (p_self == NULL)
	{
		return RC_INVALID_POINTER;
	}

	if (!p_self->initialized)
	{
		return RC_TCP_OBJECT_NOT_INITIALIZED;
	}
	return ip_recv(&p_self->super, p_buf, max_recv_len, p_recv_len);
}

#ifdef USE_THREADS

#ifndef _WIN32
static void exit_thread(pthread_t thread,void **p_thread_data)
#else
static void exit_thread(unsigned long thread,void **p_thread_data)
#endif
{

#ifndef _WIN32	

	if (thread)

		pthread_join(thread,p_thread_data);		

#else

	if (thread)
		
		WaitForSingleObject((HANDLE) thread,INFINITE);
#endif

}

#ifndef _WIN32
static void create_connect_thread(pthread_t *thread,CONNECT_THREAD_DATA *p_thread_data)
#else
static void create_connect_thread(unsigned long *thread,CONNECT_THREAD_DATA *p_thread_data)
#endif
{

#ifdef _WIN32
	*thread=_beginthread(connect_thread,0,(void *) p_thread_data);
#else
	pthread_create(thread,NULL,connect_thread,(void *) p_thread_data);
#endif

}

#ifndef _WIN32
static int kill_thread(pthread_t thread)
#else
static int kill_thread(unsigned long thread)
#endif
{

#ifndef _WIN32
	return pthread_detach(thread);
/*	return pthread_cancel(thread);*/
#else
	return 0;
#endif

}

RC_TYPE tcp_initialize_async(TCP_SOCKET *p_self,CB_EXIT_COND p_exit_func,void *p_cb_data)
{
#ifndef _WIN32
	pthread_t			c_thread=0;
#else
	unsigned long		c_thread=0;
#endif
	CONNECT_THREAD_DATA	*p_thread_data;
	CONNECT_THREAD_DATA	*p_thread_return=NULL;
	int				sleep_time=0;
	RC_TYPE			ret_rc;
	TCP_SOCKET			*p_this_self;
	int				is_t_data_mutex_released=0;



	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "Entered tcp_initialize_async...\n"));		

	if (!(p_self)) {

		DBG_PRINTF((LOG_CRIT,"C:" MODULE_TAG "p_self null in tcp_initialize_async...\n"));		

		return RC_INVALID_POINTER;
	}

	/*if client requests exit we may abandon connect thread
	  so rallocate client's p_self data -- we'll deallocate
	  this if connect thread exits normally -- so our
	  dangling thread does not have p_self data pulled out
	  from under it when/if our client quits*/

	p_this_self=safe_malloc(sizeof(TCP_SOCKET));
	memcpy(p_this_self,p_self,sizeof(TCP_SOCKET));
	p_self=p_this_self;


	p_thread_data=create_connect_data(p_self);

	get_mutex(&p_thread_data->t_data_mutex);

	create_connect_thread(&c_thread,p_thread_data);
		
	/*loop/sleep while 'til thread returns or prog exit requested*/

	while(!(p_thread_data->is_thread_exit) && !(p_exit_func(p_cb_data))) {
		
		os_sleep_ms(1000);

		sleep_time+=1000;

		if (!(sleep_time<TCP_DEFAULT_TIMEOUT)) {

			/*cancel the connect so thread returns*/
			
			DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "tcp_initialize_async timed out...\n"));		

			break;
		}
	}

	if (p_thread_data->is_thread_exit) {

		release_mutex(&p_thread_data->t_data_mutex);
		is_t_data_mutex_released=1;

	} else {

		DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "connect thread has not exited...attempting to shutdown socket in tcp_initialize_async...\n"));

		/*at least try to close the socket before effectively kill thread*/

		if (p_self->super.socket)
		
			if (!(closesocket(p_self->super.socket))) {

				p_self->super.socket=0;

				DBG_PRINTF((LOG_WARNING,"W:" MODULE_TAG "closed socket in tcp_initialize_async...\n"));
			}


		if ((kill_thread(c_thread)==0)) {
			
			c_thread=0;

			DBG_PRINTF((LOG_WARNING,"W:" MODULE_TAG "killed connect thread in tcp_initialize_async...\n"));
		}

	}

	if (c_thread) {

		DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "tcp_initialize_async joinng connect thread...\n"));

		exit_thread(c_thread,(void **) &p_thread_return);
	}

	DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "tcp_initialize_async returning...\n"));


	ret_rc=p_thread_data->rc;

	/*if program not quiting, and thread exited, free assocated data*/
	if (!(p_thread_data->is_thread_exit)) {

		p_thread_data->is_parent_exit=1;

		release_mutex(&p_thread_data->t_data_mutex);
	} 
	else {

		if (!(is_t_data_mutex_released))
			release_mutex(&p_thread_data->t_data_mutex);

		wait_sem(&p_thread_data->t_data_sem);

		DBG_PRINTF((LOG_INFO,"I:" MODULE_TAG "destroying connect data in tcp_initialize_async...\n"));

		destroy_connect_data(&p_thread_data);
	}

	return ret_rc;
}

RC_TYPE tcp_test_connect(TCP_SOCKET *p_self,CB_EXIT_COND p_exit_func,void *p_cb_data)
{

	return tcp_initialize_async(p_self,p_exit_func,p_cb_data);
}

#endif /*USE_THREADS*/

/* Accessors*/
RC_TYPE tcp_set_port(TCP_SOCKET *p_self, int p)
{
	return ip_set_port(&p_self->super, p);
}

RC_TYPE tcp_set_remote_name(TCP_SOCKET *p_self, const char* p)
{
	return ip_set_remote_name(&p_self->super, p);
}

RC_TYPE tcp_set_remote_timeout(TCP_SOCKET *p_self, int p)
{
	return ip_set_remote_timeout(&p_self->super, p);
}

RC_TYPE tcp_get_port(TCP_SOCKET *p_self, int *p)
{
	return ip_get_port(&p_self->super, p);
}

RC_TYPE tcp_get_remote_name(TCP_SOCKET *p_self, const char* *p)
{
	return ip_get_remote_name(&p_self->super, p);
}

RC_TYPE tcp_get_remote_timeout(TCP_SOCKET *p_self, int *p)
{
	return ip_get_remote_timeout(&p_self->super, p);
}
