/*-
 * Copyright (c) 2004, Sam Hopkins <sah@coraid.com>
 * Copyright (c) 2006, Stacey D. Son <sds@son.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $FreeBSD: src/sys/dev/aoe/aoedev.c,v 1.23.2.5 2004/09/22 16:50:41 ?? Exp $
 */

/*
 * aoedev.c
 * AoE device utility functions; maintains device list.
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/bio.h>
#include <sys/malloc.h>
#include <sys/kernel.h>
#include <sys/lock.h>
#include <sys/mutex.h>
#include <sys/socket.h>
#include <sys/sysctl.h>

#include <sys/conf.h>
#include <geom/geom_disk.h>

#include <net/if.h>
#include <net/if_var.h>

#include <dev/aoe/aoe.h>

static struct aoedev *devlist;
static struct mtx devlist_mtx;
static int sysctl_aoe_devices(SYSCTL_HANDLER_ARGS);

MALLOC_DEFINE(M_AOEDEV, "AoE Disk", "ATA over Ethernet Disk");
MALLOC_DEFINE(M_AOEFRAME, "AoE Frame", "ATA over Ethernet Disk Frame");

SYSCTL_DECL(_net_aoe);
SYSCTL_OID(_net_aoe, OID_AUTO, devices, CTLTYPE_STRING|CTLFLAG_RD, NULL, 0,
	sysctl_aoe_devices, "A", "AoE Device Info");

static struct aoedev *
aoedev_newdev(u_long nframes, u_long unit)
{
	struct aoedev *d;
	struct frame *f, *e;
	char buf[16];

	d = (struct aoedev *) malloc(sizeof *d, M_AOEDEV, M_NOWAIT | M_ZERO);
	if (d == NULL)
		return (NULL);
	f = (struct frame *) malloc(nframes * sizeof *f, M_AOEFRAME, M_NOWAIT | M_ZERO);
	if (f == NULL) {
		free(d, M_AOEDEV);
		return (NULL);
	}

	d->ad_nframes = nframes;
	d->ad_frames = f;
	e = f + nframes;
	for (; f<e; f++)
		f->f_tag = FREETAG;

	callout_init(&d->ad_callout, 1);
	bioq_init(&d->ad_bioq);
	snprintf(buf, sizeof buf, "aoed%ld", unit);
	mtx_init(&d->ad_mtx, buf, NULL, MTX_DEF);

	mtx_lock(&devlist_mtx);
	d->ad_next = devlist;
	devlist = d;
	mtx_unlock(&devlist_mtx);

	return (d);
}

void
aoedev_freedev(struct aoedev *d)
{
	free(d->ad_frames, M_AOEFRAME);
	mtx_destroy(&d->ad_mtx);
	free(d, M_AOEDEV);
}

void
aoedev_downdev(struct aoedev *d)
{
	struct frame *f, *e;
	struct bio *bp;

	atomic_set_32(&d->ad_flags, DEVFL_TKILL);
	callout_stop(&d->ad_callout);

	f = d->ad_frames;
	e = f + d->ad_nframes;
	for (; f<e; f++) {
		if (f->f_tag != FREETAG) {
			if ((bp = f->f_bp)) {
				bp->bio_error = EIO;
				bp->bio_flags |= BIO_ERROR;
				bp->bio_aoe_nbuflets = (void *) ((u_long) bp->bio_aoe_nbuflets - 1);
				if (bp->bio_aoe_nbuflets == 0)
					biodone(bp);
			}
			f->f_tag = FREETAG;
			f->f_bp = NULL;
		}
	}
	d->ad_inprocess = NULL;

	bioq_flush(&d->ad_bioq, NULL, EIO);

	if (d->ad_flags & DEVFL_OPEN)
		atomic_set_32(&d->ad_flags, DEVFL_CLOSEWAIT);
	else if (d->ad_flags & DEVFL_UP && aoeblk_unregister(d) != 0) {
		IPRINTK("Can't unregister disk.  "
			"Expect buggy behaviour.\n");
	}
	atomic_clear_32(&d->ad_flags, DEVFL_UP);
}

/*
 * (1) If the unit/addr is ok, but the device is not up
 * we force reset the device to flush the outstanding
 * messages (the potential ata ident).  This is just to
 * be safe.
 */
struct aoedev *
aoedev_set(u_long unit, char *addr, struct ifnet *ifp, u_long bufcnt)
{
	struct aoedev *d;

	mtx_lock(&devlist_mtx);
	for (d=devlist; d; d=d->ad_next)
		if (d->ad_unit == unit
		/* || memcmp(d->ad_addr, addr, sizeof d->ad_addr) == 0 */ )
			break;
	mtx_unlock(&devlist_mtx);

	if (d == NULL) {
		d = aoedev_newdev(bufcnt, unit);
		if (d == NULL) {
			IPRINTK("aoedev_newdev failure.\n");
			return (NULL);
		}
	}

	mtx_lock(&d->ad_mtx);

	d->ad_ifp = ifp;

	if (d->ad_unit != unit
	/* || memcmp(d->ad_addr, addr, sizeof d->ad_addr) */
	|| (d->ad_flags & DEVFL_UP) == 0) {	/* (1) */
		aoedev_downdev(d);
		memcpy(d->ad_addr, addr, sizeof d->ad_addr);
		d->ad_unit = unit;
		d->ad_major = AOEMAJOR(unit);
		d->ad_minor = AOEMINOR(unit);
	}

	mtx_unlock(&d->ad_mtx);
	return (d);
}

struct aoedev *
aoedev_byaddr(char *addr)
{
	struct aoedev *d;

	mtx_lock(&devlist_mtx);
	for (d=devlist; d; d=d->ad_next)
		if (memcmp(d->ad_addr, addr, sizeof d->ad_addr) == 0)
			break;
	mtx_unlock(&devlist_mtx);

	return (d);
}

struct aoedev *
aoedev_byunit(u_long unit)
{
	struct aoedev *d;

	mtx_lock(&devlist_mtx);
	for (d=devlist; d; d=d->ad_next)
		if (d->ad_unit == unit)
			break;
	mtx_unlock(&devlist_mtx);

	return (d);
}

boolean_t
aoedev_busy(void)
{
	struct aoedev *d;
	enum { BUSYFLAGS = DEVFL_OPEN | DEVFL_TASKON };

	mtx_lock(&devlist_mtx);
	d = devlist;
	for (; d; d=d->ad_next) {
		mtx_lock(&d->ad_mtx);
		if (d->ad_flags & BUSYFLAGS) {
			mtx_unlock(&d->ad_mtx);
			mtx_unlock(&devlist_mtx);
			return (TRUE);
		}
		mtx_unlock(&d->ad_mtx);
	}
	mtx_unlock(&devlist_mtx);
	return (FALSE);
}

/* approach taken from vm/uma_core.c */
static int
sysctl_aoe_devices(SYSCTL_HANDLER_ARGS)
{
	char *buf;
	struct aoedev *d;
	register int n;
	enum { LINESZ = 64 };

	mtx_lock(&devlist_mtx);
	if (devlist == NULL) {
		mtx_unlock(&devlist_mtx);
		return (SYSCTL_OUT(req, "\0", 1));
	}

	n = 0;
	for (d=devlist; d; d=d->ad_next)
		n += LINESZ;
	buf = (char *) malloc(n+1, M_TEMP, M_NOWAIT | M_ZERO);
	if (buf == NULL) {
		IPRINTK("could not malloc "
			"buffer size %d to print device list\n", n);
		mtx_unlock(&devlist_mtx);
		return (ENOMEM);
	}

	n = 0;
	for (d=devlist; d; d=d->ad_next) {
		n += snprintf(buf+n, LINESZ, "\naoed%-6ld\t%s\t%s%s%s\t(%d)",
			d->ad_unit,
			d->ad_ifp->if_xname,
			(d->ad_flags & DEVFL_UP) ? "UP" : "DOWN",
			(d->ad_flags & DEVFL_OPEN) ? ",OPEN" : "",
			(d->ad_flags & DEVFL_CLOSEWAIT) ? ",CLOSEWAIT" : "",
			d->ad_disk->d_maxsize);
	}
	mtx_unlock(&devlist_mtx);

	n = SYSCTL_OUT(req, buf, n+1);
	free(buf, M_TEMP);
	return (n);
}

/*
 * Flag devices for update.  Accomplished on next call to 
 * individual aoecmd_work().
 */
void
aoedev_wc_update(void)
{
	struct aoedev *d;

	mtx_lock(&devlist_mtx);
	for (d=devlist; d; d=d->ad_next) 
		atomic_set_32(&d->ad_flags, DEVFL_WC_UPDATE);
	mtx_unlock(&devlist_mtx);
}

void
aoedev_init(void)
{
	mtx_init(&devlist_mtx, "AoE devlist mutex", NULL, MTX_DEF);
}

void
aoedev_exit(void)
{
	struct aoedev *d;

	while ((d = devlist)) {
		devlist = d->ad_next;
		mtx_lock(&d->ad_mtx);
		aoedev_downdev(d);
		mtx_unlock(&d->ad_mtx);

		callout_drain(&d->ad_callout);
		while (d->ad_flags & DEVFL_TASKON)
			tsleep(d, 0, "aoeunl", hz>>1);
		aoedev_freedev(d);
	}
	mtx_destroy(&devlist_mtx);
}

