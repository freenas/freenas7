/*-
 * Copyright (c) 2004, Sam Hopkins <sah@coraid.com>
 * Copyright (c) 2006, Stacey D. Son <sds@son.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <sys/cdefs.h>
__FBSDID("$FreeBSD: src/sys/dev/aoe/aoecmd.c,v 1.23.2.5 2004/09/22 16:50:41 ?? Exp $");

/*
 * aoecmd.c
 * AoE command request handling methods
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/ata.h>
#include <sys/bio.h>
#include <sys/kernel.h>
#include <sys/lock.h>
#include <sys/mutex.h>
#include <sys/mbuf.h>
#include <sys/sysctl.h>

#include <dev/aoe/aoe.h>

#define TIMERTICK (hz / 10)
#define MINTIMER (2 * TIMERTICK)
#define MAXTIMER (hz << 1)
#define MAXWAIT (60 * 3)	/* After MAXWAIT rexmit time, give up and fail device. */

extern boolean_t aoe_exiting;
static int aoe_maxwait = MAXWAIT;
static int aoe_wc = 1;
static int sysctl_aoe_wc(SYSCTL_HANDLER_ARGS);

SYSCTL_DECL(_net_aoe);
SYSCTL_INT(_net_aoe, OID_AUTO, maxwait, CTLFLAG_RW, &aoe_maxwait, 0, 
	"Max rexmit wait seconds before failing a device");
SYSCTL_OID(_net_aoe, OID_AUTO, wc, CTLTYPE_INT|CTLFLAG_RW, &aoe_maxwait, 0,
	sysctl_aoe_wc, "I", "AoE ATA device write cache enable / disable");

static struct frame *
getframe(struct aoedev *d, int tag)
{
	struct frame *f, *e;

	f = d->ad_frames;
	e = f + d->ad_nframes;
	for (; f<e; f++)
		if (f->f_tag == tag)
			return (f);
	return (NULL);
}

/*
 * Leave the top bit clear so we have tagspace for userland.
 * The bottom 16 bits are the xmit tick for rexmit/rttavg processing.
 * This driver reserves tag -1 to mean "unused frame."
 */
static int
newtag(struct aoedev *d)
{
	register int n;

	n = ticks & 0xffff;
	n |= (++d->ad_lasttag & 0x7fff) << 16;
	return (n);
}

static int
aoehdr_atainit(struct aoedev *d, struct aoe_hdr *h)
{
	int host_tag;

	host_tag = newtag(d);

	memcpy(h->ah_src, aoenet_enaddr(d->ad_ifp), sizeof(h->ah_src));
	memcpy(h->ah_dst, d->ad_addr, sizeof(h->ah_dst));
	h->ah_type = htons(ETHERTYPE_AOE);
	h->ah_verfl = AOE_HVER;
	h->ah_major = htons(d->ad_major);
	h->ah_minor = d->ad_minor;
	h->ah_cmd = AOECMD_ATA;
	h->ah_tag = htonl(host_tag);

	return (host_tag);
}

static inline void
put_lba(struct aoe_atahdr *ah, daddr_t lba)
{
	ah->aa_lba0 = lba;
	ah->aa_lba1 = lba >>= 8;
	ah->aa_lba2 = lba >>= 8;
	ah->aa_lba3 = lba >>= 8;
	ah->aa_lba4 = lba >>= 8;
	ah->aa_lba5 = lba >>= 8;
}

static void
aoecmd_ata_rw(struct aoedev *d, struct frame *f)
{
	struct aoe_hdr *h;
	struct aoe_atahdr *ah;
	struct bio *bp;
	u_long bcnt;
	u_int dsz;
	register daddr_t sector;
	char writebit, extbit;

	writebit = 0x10;
	extbit = 0x4;

	bp = d->ad_inprocess;

	/* Since we can't touch bio_pblkno we calc the current sector.  */
	sector = ((char *) bp->bio_aoe_baddr - bp->bio_data) >> DEV_BSHIFT;
	sector += bp->bio_pblkno;

	/*
	 * Limit amount sent by frame size.
	 * Check what the mtu is set to and set accordingly. 
	 */
	bcnt = bp->bio_resid;

	dsz = aoenet_maxsize(d->ad_ifp); 
	if (bcnt > dsz) 
		bcnt = dsz; 

	/* Initialize the headers & frame. */
	h = (struct aoe_hdr *) f->f_hdr;
	ah = (struct aoe_atahdr *) (h+1);
	bzero(h, sizeof(*h) + sizeof(*ah));
	f->f_mlen = sizeof(*h) + sizeof(*ah);
	f->f_tag = aoehdr_atainit(d, h);
	f->f_waited = 0;
	f->f_bp = bp;
	f->f_data = NULL;

	/* Set up ata header. */
	ah->aa_scnt = bcnt >> DEV_BSHIFT;
	put_lba(ah, sector);
	if (d->ad_flags & DEVFL_EXT) {
		ah->aa_aflags |= AOEAFL_EXT;
	} else {
		extbit = 0;
		ah->aa_lba3 &= 0x0f;
		ah->aa_lba3 |= 0xe0;	/* LBA bit + obsolete 0xa0. */
	}
	if (bp->bio_cmd == BIO_READ) {
		writebit = 0;
		f->f_bioaddr = bp->bio_aoe_baddr;
	} else {
		ah->aa_aflags |= AOEAFL_WRITE;
		f->f_data = bp->bio_aoe_baddr;
		f->f_mlen += bcnt;
	}
	ah->aa_cmdstat = ATA_READ | writebit | extbit;

	/* Now mark all our tracking fields and load out. */
	bp->bio_aoe_nbuflets = (void *) ((u_long) bp->bio_aoe_nbuflets + 1);
	bp->bio_aoe_baddr = (void *) ((char *) bp->bio_aoe_baddr + bcnt);
	bp->bio_resid -= bcnt;
	if (bp->bio_resid == 0)		/* We have satisfied strategy bio. */
		d->ad_inprocess = NULL;

	if(aoenet_xmitframe(d, f))
		IPRINTK("Could not send frame\n");
}

static void
rexmit(struct aoedev *d, struct frame *f)
{
	/* struct mbuf *m; */
	struct aoe_hdr *h;
	struct aoe_atahdr *ah;

	h = (struct aoe_hdr *) f->f_hdr;
	ah = (struct aoe_atahdr *) (h+1);

#ifdef AOE_DEBUG

	IPRINTK("mlen=%ld verfl=%X major=%X minor=%X cmd=%X\n"
		"\ttag=%lX aflags=%X errfeat=%X scnt=%X cmdstat=%X\n"
		"\tlba0=%X lba1=%X lba2=%X lba3=%X lba4=%X lba5=%X\n",
		f->f_mlen, h->ah_verfl, ntohs(h->ah_major), h->ah_minor, h->ah_cmd,
		ntohl(h->ah_tag), ah->aa_aflags, ah->aa_errfeat, ah->aa_scnt, 
		ah->aa_cmdstat, ah->aa_lba0, ah->aa_lba1, ah->aa_lba2, 
		ah->aa_lba3, ah->aa_lba4, ah->aa_lba5);
#endif

	/* hnput32(h->tag, f->f_tag = newtag(d)); */
	f->f_tag = newtag(d);
	h->ah_tag = htonl(f->f_tag);
	
	if (aoenet_xmitframe(d, f))
		IPRINTK("Could not send frame\n");
}

/* How long since we sent this tag? */
static int
tsince(int tag)
{
	int n;

	n = ticks & 0xffff;
	n -= tag & 0xffff;
	if (n < 0)
		n += 1<<16;
	return (n);
}

static void
rexmit_timer(void *vp)
{
	int n, ntx;
	struct aoedev *d = vp;
	struct frame *f, *e;
	register int timeout;

	/* if (aoe_isexiting()) */
	if (aoe_exiting)
		return;

	mtx_lock(&d->ad_mtx);

	/* Timeout is always ~150% of the moving average. */
	timeout = d->ad_rttavg;
	timeout += timeout >> 1;
	ntx = 0;

	if (d->ad_flags & DEVFL_TKILL) {
		mtx_unlock(&d->ad_mtx);
		return;
	}
	f = d->ad_frames;
	e = f + d->ad_nframes;
	for (; f<e; f++) {
		if (f->f_tag != FREETAG)
		if (f->f_tag != INPROCTAG)
		if (tsince(f->f_tag) >= timeout) {
			n = f->f_waited += timeout;
			n /= hz;
			if (n > aoe_maxwait) {	/* Waited too long.  Device failure. */
				aoedev_downdev(d);
				mtx_unlock(&d->ad_mtx);
				return;
			}
			ntx++;
			rexmit(d, f);
		}
	}
	if (ntx) {
		n = d->ad_rttavg <<= 1;
		if (n > MAXTIMER)
			d->ad_rttavg = MAXTIMER;
	}
	callout_reset(&d->ad_callout, TIMERTICK, rexmit_timer, d);

	mtx_unlock(&d->ad_mtx);
}

/* Command to send an ATA write cache update. */
static void
aoecmd_ata_wc(struct aoedev *d, struct frame *f)
{
	struct aoe_hdr *h;
	struct aoe_atahdr *ah;
	/* struct mbuf *m; */

	/* Initialize the headers & frame. */
	h = (struct aoe_hdr *) f->f_hdr;
	ah = (struct aoe_atahdr *) (h+1);
	bzero(h, sizeof *h + sizeof *ah);
	f->f_mlen = sizeof *h + sizeof *ah;
	f->f_tag = aoehdr_atainit(d, h);
	f->f_waited = 0;
	f->f_data = NULL;

	/* Set up ata header. */
	ah->aa_cmdstat = ATA_SETFEATURES;
	ah->aa_errfeat = aoe_wc ? ATA_SF_ENAB_WCACHE : ATA_SF_DIS_WCACHE;
	ah->aa_lba3 = 0xa0;	/* Obsolete bits per ATA6. */

	if (aoenet_xmitframe(d, f))
		IPRINTK("Could not send frame\n");
}

/* Command to send an ATA identify. */
static void
aoecmd_ata_id(struct aoedev *d)
{
	struct aoe_hdr *h;
	struct aoe_atahdr *ah;
	struct frame *f;
	/* struct mbuf *m; */

	f = getframe(d, FREETAG);
	if (f == NULL) {
		IPRINTK("can't get a frame.  This shouldn't happen.\n");
		return;
	}

	/* Initialize the headers & frame. */
	h = (struct aoe_hdr *) f->f_hdr;
	ah = (struct aoe_atahdr *) (h+1);
	bzero(h, sizeof *h + sizeof *ah);
	f->f_mlen = sizeof *h + sizeof *ah;
	f->f_tag = aoehdr_atainit(d, h);
	f->f_waited = 0;
	f->f_data = NULL;

	/* This message initializes the device, so we reset the rttavg. */
	d->ad_rttavg = MAXTIMER;

	/* Set up ata header. */
	ah->aa_scnt = 1;
	ah->aa_cmdstat = ATA_ATA_IDENTIFY;
	ah->aa_lba3 = 0xa0;

	if (aoenet_xmitframe(d, f)) {
		IPRINTK("Could not send frame\n");
		return;
	}

	atomic_clear_32(&d->ad_flags, DEVFL_TKILL);
	callout_reset(&d->ad_callout, TIMERTICK, rexmit_timer, d);
}

void
aoecmd_cfg_rsp(struct mbuf *m)
{
	struct aoedev *d;
	struct aoe_hdr *h;
	struct aoe_cfghdr *ch;
	u_long unit, bufcnt;
	enum { MAXFRAMES = 8 };

	h = mtod(m, struct aoe_hdr *);
	ch = (struct aoe_cfghdr *) (h+1);

	unit = AOEUNIT(ntohs(h->ah_major), h->ah_minor);

	bufcnt = ntohs(ch->ac_bufcnt);
	if (bufcnt > MAXFRAMES)		/* Let's keep it reasonable. */
		bufcnt = MAXFRAMES;

	d = aoedev_set(unit, h->ah_src, m->m_pkthdr.rcvif, bufcnt);
	if (d == NULL) {
		IPRINTK("failure setting device\n");
		return;
	}

	mtx_lock(&d->ad_mtx);

	if (d->ad_flags & (DEVFL_UP | DEVFL_CLOSEWAIT)) {
		mtx_unlock(&d->ad_mtx);
		return;
	}

	/* We get here only if the device is new. */
	aoecmd_ata_id(d);

	mtx_unlock(&d->ad_mtx);
}

void
aoecmd_work(struct aoedev *d)
{
	struct bio *bp;
	struct frame *f;
loop:
	f = getframe(d, FREETAG);
	if (f == NULL)
		return;
	if (d->ad_flags & DEVFL_WC_UPDATE) {
		aoecmd_ata_wc(d, f);
		atomic_clear_32(&d->ad_flags, DEVFL_WC_UPDATE);
		goto loop;
	}
	if (d->ad_inprocess == NULL) {
		bp = bioq_first(&d->ad_bioq);
		if (bp == NULL)
			return;
		bioq_remove(&d->ad_bioq, bp);
	
		switch (bp->bio_cmd) {
		default:
			IPRINTK("unknown bio op 0x%X\n", bp->bio_cmd);
			biofinish(bp, NULL, EOPNOTSUPP);
			goto loop;	/* Yep, it sure is. */
		case BIO_READ:
		case BIO_WRITE:
			break;
		}

		bp->bio_aoe_baddr = bp->bio_data;
		bp->bio_aoe_nbuflets = 0;
		bp->bio_resid = bp->bio_bcount;
		d->ad_inprocess = bp;
	}
	aoecmd_ata_rw(d, f);
	goto loop;
}

static u_short
lhget16(u_char *p)
{
        u_short n;

        n = p[1];
        n <<= 8;
	n |= p[0];
        return (n);
}

static u_long
lhget32(u_char *p)
{
        u_long n;

        n = lhget16(p+2);
        n <<= 16;
        n |= lhget16(p);
        return (n);
}


static void
ataid_complete(struct aoedev *d, char *id)
{
	int n;

	memcpy(d->ad_ident, id, sizeof d->ad_ident);

	n = lhget16(id + (83<<1));		/* Command set supported. */
	if (n & (1<<10)) {			/* Lba48 */
		atomic_set_32(&d->ad_flags, DEVFL_EXT);
		d->ad_nsectors = lhget32(id + (100<<1));	/* n lba48 sectors. */
	} else {
		atomic_clear_32(&d->ad_flags, DEVFL_EXT);
		d->ad_nsectors = lhget32(id + (60<<1));	/* n lba28 sectors. */
	}
	if (aoeblk_register(d) != 0)
		IPRINTK("could not register disk\n");
}

static void
calc_rttavg(struct aoedev *d, int rtt)
{
	register long n;

        n = rtt;
        if (n < 0) {
                n = -rtt;
                if (n < MINTIMER)
                        n = MINTIMER;
                else if (n > MAXTIMER)
                        n = MAXTIMER;
                d->ad_mintimer += (n - d->ad_mintimer) >> 1;
        } else if (n < d->ad_mintimer)
                n = d->ad_mintimer;
        else if (n > MAXTIMER)
                n = MAXTIMER;

	/* g == .25; cf. Congestion Avoidance and Control, Jacobson & Karels; 1988. */
	n -= d->ad_rttavg;
	d->ad_rttavg += n >> 2;
}

void
aoecmd_ata_rsp(struct mbuf *m)
{
	struct aoedev *d;
	struct aoe_hdr *hin;
	struct aoe_atahdr *ahin, *ahout;
	struct frame *f;
	struct bio *bp;
	register long n;

	hin = mtod(m, struct aoe_hdr *);
	d = aoedev_byunit(AOEUNIT(ntohs(hin->ah_major), hin->ah_minor));

	if (d == NULL) {
		IPRINTK("response for unknown device %d.%d\n",
			ntohs(hin->ah_major), hin->ah_minor);
		/* Maybe run a discover cfg on this eaddr? */
		return;
	}

	mtx_lock(&d->ad_mtx);
	
	n = ntohl(hin->ah_tag);
	f = getframe(d, n);
	if (f == NULL) {
		calc_rttavg(d, -tsince(n));
		mtx_unlock(&d->ad_mtx);
		IPRINTK("unsolicited response from %d.%d\n", 
			ntohs(hin->ah_major), hin->ah_minor);
		return;
	}

	calc_rttavg(d, tsince(f->f_tag));

	ahin = (struct aoe_atahdr *) (hin+1);
	ahout = (struct aoe_atahdr *) (f->f_hdr + sizeof(*hin));
	bp = f->f_bp;

	if (ahin->aa_cmdstat & 0xa9) {	/* These bits cleared on success. */
		IPRINTK("ata error cmd=%2.2Xh stat=%2.2Xh\n", 
			ahout->aa_cmdstat, ahin->aa_cmdstat);
		if (bp)
			bp->bio_flags |= BIO_ERROR;
		/* Smartmontools won't get errors.  oh well. */
	} else {
		switch (ahout->aa_cmdstat) {
		case ATA_READ:
		case ATA_READ48:
			n = ahout->aa_scnt << DEV_BSHIFT;
			/* if (m->m_len - sizeof *hin - sizeof *ahin < n) { */
			if (m->m_pkthdr.len - sizeof *hin - sizeof *ahin < n) {
				IPRINTK("runt ata data size in read.  len=%d\n", 
					m->m_pkthdr.len);

				/* Fail frame f ?  Just returning will rexmit. */
				mtx_unlock(&d->ad_mtx);
				return;
			}
			/* memcpy(f->f_bioaddr, ahin+1, n); */
			m_copydata(m, AOEHDRSZ, n, f->f_bioaddr);
			break;
		case ATA_WRITE:
		case ATA_WRITE48:
			break;
		case ATA_SETFEATURES:
			if (ahin->aa_errfeat & (1<<2))
				IPRINTK("setfeatures failure for %ld\n", 
					d->ad_unit);
			break;
		case ATA_ATA_IDENTIFY:
			if (m->m_pkthdr.len - sizeof *hin - sizeof *ahin < 512) {
				IPRINTK("runt ata data size in ataid\n");
				break;
			}
			ataid_complete(d, (char *) (ahin+1));
			atomic_set_32(&d->ad_flags, DEVFL_WC_UPDATE);
			break;
		case ATA_SMART:
			/* n = m->m_len; */
			n = m->m_pkthdr.len;
			if (n > sizeof f->f_hdr)
				n = sizeof f->f_hdr;
			memcpy(f->f_hdr, hin, n);
			f->f_tag = INPROCTAG;
			wakeup(d);
			mtx_unlock(&d->ad_mtx);
			return;
		default:
			IPRINTK("unrecognized ata command %2.2Xh from %d.%d\n", 
				ahout->aa_cmdstat, ntohs(hin->ah_major), hin->ah_minor);
		}
	}

	if (bp) {
		bp->bio_aoe_nbuflets = (void *) ((u_long) bp->bio_aoe_nbuflets - 1);
		if (bp->bio_aoe_nbuflets == 0)
		if (bp->bio_resid == 0)
			biodone(bp);
	}

	f->f_bp = NULL;
	f->f_tag = FREETAG;
	aoecmd_work(d);

	mtx_unlock(&d->ad_mtx);
}

/* Send an AoE Config Query to all available network interfaces. */
void
aoecmd_cfg(u_short major, u_char minor)
{
	aoenet_xmitbcast(major, minor);
}

/* Send an ATA smart command set up from ioctl. */
int
aoecmd_ata_smart(struct aoedev *d, struct ata_ioc_request *iocmd)
{
	struct frame *f;
	struct aoe_hdr *h;
	struct aoe_atahdr *ah;
	register daddr_t lba;
	int timeout;

	timeout = iocmd->ata_ioc_request_timeout;

	while ((f = getframe(d, FREETAG)) == NULL) {
		msleep(d, &d->ad_mtx, 0, "aoesmt", hz>>1);
		timeout -= hz>>1;
		if (timeout < 0) {
			IPRINTK("frame access timeout\n");
			return (EIO);
		}
	}

	/* Initialize the headers & frame. */
	h = (struct aoe_hdr *) f->f_hdr;
	ah = (struct aoe_atahdr *) (h+1);
	bzero(h, sizeof *h + sizeof *ah);
	f->f_mlen = sizeof *h + sizeof *ah;
	f->f_tag = aoehdr_atainit(d, h);
	f->f_waited = 0;

	/* Set up ata header. */
	ah->aa_cmdstat = iocmd->ata_ioc_request_ata.command;
        ah->aa_scnt = iocmd->ata_ioc_request_ata.count;
        ah->aa_errfeat = iocmd->ata_ioc_request_ata.feature;
        lba = iocmd->ata_ioc_request_ata.lba;
	put_lba(ah, lba);

	if (aoenet_xmitframe(d, f))
		IPRINTK("Could not send frame\n");

	if (msleep(d, &d->ad_mtx, 0, "aoesmt", timeout) == EWOULDBLOCK) {
		f->f_tag = FREETAG;
		IPRINTK("command timeout\n");
		return (EIO);
	}

	/* At this point, response has been copied over request. */
        iocmd->ata_ioc_request_ata.command = ah->aa_cmdstat;
        iocmd->ata_ioc_request_ata.feature = ah->aa_errfeat;
        iocmd->ata_ioc_request_ata.count = ah->aa_scnt;


	lba = ah->aa_lba3 << 24;
	lba |= ah->aa_lba2 << 16;
	lba |= ah->aa_lba1 << 8;
	lba |= ah->aa_lba0;
	iocmd->ata_ioc_request_ata.lba = lba;

	if (iocmd->ata_ioc_request_flags == ATA_CMD_READ)
		copyout(ah+1, iocmd->ata_ioc_request_data, iocmd->ata_ioc_request_count);

	f->f_tag = FREETAG;
	return (0);
}

/* Set the write caching. */
static int
sysctl_aoe_wc(SYSCTL_HANDLER_ARGS)
{
	int n, err;

	n = aoe_wc;

	err = SYSCTL_OUT(req, &aoe_wc, sizeof aoe_wc);
	if (err || !req->newptr)
		return (err);

	err = SYSCTL_IN(req, &aoe_wc, sizeof aoe_wc);
	if (err)
		return (err);
	if (aoe_wc)		/* KISS. */
		aoe_wc = 1;
	if (n != aoe_wc)
		aoedev_wc_update();
	return (0);
}
