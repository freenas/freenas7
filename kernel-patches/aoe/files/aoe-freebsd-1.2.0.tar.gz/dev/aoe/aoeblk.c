/*-
 * Copyright (c) 2004, Sam Hopkins <sah@coraid.com>
 * Copyright (c) 2006, Stacey D. Son <sds@son.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $FreeBSD: src/sys/dev/aoe/aoeblk.c,v 1.23.2.5 2004/09/22 16:50:41 ?? Exp $
 */

/*
 * aoeblk.c
 * geom_disk routines
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/ata.h>
#include <sys/bio.h>
#include <sys/conf.h>
#include <sys/devicestat.h>
#include <sys/lock.h>
#include <sys/mutex.h>
#include <sys/taskqueue.h>

#include <geom/geom_disk.h>

#include <dev/aoe/aoe.h>

extern boolean_t aoe_exiting;

static int
aoeblk_open(struct disk *disk)
{
	struct aoedev *d;

	if (aoe_exiting)
		return (EBUSY);

	d = disk->d_drv1;
	if ((d->ad_flags & DEVFL_UP) == 0) {
		IPRINTK("AoE device %ld is not up.\n", d->ad_unit);
		return (EBUSY);
	}
	atomic_set_32(&d->ad_flags, DEVFL_OPEN);

	return (0);
}

/*
 * (1) On final close we might be waiting to reinitialize the
 * blade.  If so, we'll unregister the disk (which will eventually
 * trigger reinitialization when complete).
 */
static int
aoeblk_close(struct disk *disk)
{
	struct aoedev *d;

	d = disk->d_drv1;
	atomic_clear_32(&d->ad_flags, DEVFL_OPEN);
	if ((d->ad_flags & DEVFL_CLOSEWAIT) &&	/* (1) */
	    (aoeblk_unregister(d) != 0)) {
		IPRINTK("can't unregister disk.  "
			"Expect buggy behaviour.\n");
	}

	return (0);
}

static void
aoeblk_strategy(struct bio *bp)
{
	struct aoedev *d;

	d = bp->bio_disk->d_drv1;
	mtx_lock(&d->ad_mtx);
	if ((d->ad_flags & DEVFL_UP) == 0) {
		biofinish(bp, NULL, EIO);
		mtx_unlock(&d->ad_mtx);
		return;
	}
	bioq_disksort(&d->ad_bioq, bp);
	aoecmd_work(d);
	mtx_unlock(&d->ad_mtx);
}

/*
 * Ioctl only for select smartmontools ata commands.
 * We fake out the ATAREQUEST ata ioctl -- ugly, but effective.
 */
static int
aoeblk_ioctl(struct disk *disk, u_long cmd, void *vp, int flag, struct thread *td)
{
	struct ata_ioc_request *iocmd;
	struct aoedev *d;
	int n;

	if (cmd != IOCATAREQUEST) {
		IPRINTK("cmd %ld not IOCATA.\n", cmd);
		return (ENOTTY);
	}

	iocmd = (struct ata_ioc_request *) vp;
	if (iocmd == NULL) {
		IPRINTK("NULL arg ptr.\n");
		return (EINVAL);
	}

/*
	if (iocmd->cmd != ATAREQUEST) {
		IPRINTK("Unknown iocmd->cmd=%d\n", iocmd->cmd);
		return (ENOTTY);
	}
*/

	if (iocmd->ata_ioc_request_count) {
		if (iocmd->ata_ioc_request_data == NULL) {
			IPRINTK("null return data pointer\n");
			return (EINVAL);
		}
		iocmd->ata_ioc_request_count = 512;
		iocmd->ata_ioc_request_ata.count = 1;
	}

	d = disk->d_drv1;
	mtx_lock(&d->ad_mtx);
	if ((d->ad_flags & DEVFL_UP) == 0) {
		IPRINTK("device for unit %ld is not up.\n", d->ad_unit);
		mtx_unlock(&d->ad_mtx);
		return (ENXIO);
	}

	switch (iocmd->ata_ioc_request_ata.command) {
	case ATA_ATA_IDENTIFY:
		copyout(d->ad_ident, iocmd->ata_ioc_request_data, sizeof d->ad_ident);
		mtx_unlock(&d->ad_mtx);
		return (0);
	case ATA_SMART:
		if (iocmd->ata_ioc_request_ata.feature != ATA_SMART_ATTR_AUTOSAVE) {
			n = aoecmd_ata_smart(d, iocmd);
			mtx_unlock(&d->ad_mtx);
			return (n);
		}
	default:
		mtx_unlock(&d->ad_mtx);
		IPRINTK("unallowed ata command; "
			"cmd=%2.2X feat=%2.2X.\n", 
			iocmd->ata_ioc_request_ata.command,
			iocmd->ata_ioc_request_ata.feature);
		return (EINVAL);
	}
}

static void
disk_create_task(void *ctx, int useless __unused)
{
	struct disk *disk;
	struct aoedev *d;

	d = (struct aoedev *) ctx;

	disk = disk_alloc();	/* Disk_destroy triggers freeing the allocated disk. */
	if (disk == NULL) {
		IPRINTK("cannot alloc disk structure.\n");
		atomic_clear_32(&d->ad_flags, DEVFL_TASKON);
		return;
	}

	d->ad_disk = disk;
	disk->d_drv1 = d;
	/* disk->d_maxsize = DFLTPHYS; */ 
	disk->d_maxsize = aoenet_maxsize(d->ad_ifp);  
	disk->d_sectorsize = DEV_BSIZE;
	disk->d_mediasize = DEV_BSIZE * d->ad_nsectors;
	disk->d_unit = d->ad_unit;
	disk->d_name = "aoed";
	disk->d_open = aoeblk_open;
	disk->d_close = aoeblk_close;
	disk->d_ioctl = aoeblk_ioctl;
	disk->d_strategy = aoeblk_strategy;

	disk_create(disk, DISK_VERSION_00);

	atomic_clear_32(&d->ad_flags, DEVFL_TASKON);
	atomic_set_32(&d->ad_flags, DEVFL_UP);
}

/*
 * (1) If we are in closewait state the device has either
 * failed or its identity has changed (eaddr, major, minor).
 * We schedule a discovery in either case to give it a
 * chance to reinitialize.
 */
static void
disk_destroy_task(void *ctx, int useless __unused)
{
	struct aoedev *d;
	int flags;

	d = (struct aoedev *) ctx;

	disk_destroy(d->ad_disk);

	mtx_lock(&d->ad_mtx);
	d->ad_disk = NULL;
	flags = d->ad_flags;
	atomic_clear_32(&d->ad_flags, DEVFL_TASKON|DEVFL_CLOSEWAIT);
	mtx_unlock(&d->ad_mtx);

	if (flags & DEVFL_CLOSEWAIT)	/* (1) */
		aoecmd_cfg(d->ad_major, d->ad_minor);
}

static int
runtask(task_fn_t fn, struct aoedev *d)
{
	struct task *t;
	int n;

	if (d->ad_flags & DEVFL_TASKON)
		return (EBUSY);

	t = &d->ad_task;
	TASK_INIT(t, 0, fn, d);

	n = taskqueue_enqueue(taskqueue_thread, t);
	if (n == 0)
		atomic_set_32(&d->ad_flags, DEVFL_TASKON);
	return (n);
}

int
aoeblk_register(struct aoedev *d)
{
	int n;

	n = runtask(disk_create_task, d);
	if (n != 0)
		IPRINTK("runtask failure.\n");
	return (n);
}

int
aoeblk_unregister(struct aoedev *d)
{
	int n;

	n = runtask(disk_destroy_task, d);
	if (n != 0)
		IPRINTK("runtask failure.\n");
	return (n);
}

