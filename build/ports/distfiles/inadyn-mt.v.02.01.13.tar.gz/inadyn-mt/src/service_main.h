#include <stdio.h>
#include <stdlib.h>

#define _SERVICE_INSTALL     "-i"
#define _SERVICE_START       "-s"
#define _SERVICE_RESTART     "-r"
#define _SERVICE_EXIT        "-e"
#define _SERVICE_UNINSTALL   "-x"
#define _SERVICE_LOG         "--service_log"

typedef DWORD SERVICE_EVENT;
typedef DWORD (*SERVICE_CLIENT_ENTRY)(int argc, char* argv[],FILE *pLOG_FILE);
typedef DWORD (*SERVICE_EVENT_HANDLER)(SERVICE_EVENT p_service_event);

typedef struct SERVICE_REG_ENTRY {

  char     regKey[1024];
  char     regKeyValueNameAr[256][256];
  void     *regKeyValueAr[256];

  DWORD    regKeyValueTypeAr[256];

} SERVICE_REG_ENTRY;

BOOL isService();
int set_up_service(int argc,char *argv[],char *szName,SERVICE_REG_ENTRY *service_reg_entry,SERVICE_CLIENT_ENTRY 
                   service_client_callback,SERVICE_EVENT_HANDLER service_event_handler,FILE *p_log_file);
void insert_app_paramters(int *argc,char *argv[],char *szDest[],char *szServiceName);
int get_registry_parameters(char *szDest[]);
BOOL get_app_parameters(LPTSTR szParamStr,DWORD buffLen,LPTSTR szServiceName,LPTSTR szRegKey,LPTSTR szRegValueName);
