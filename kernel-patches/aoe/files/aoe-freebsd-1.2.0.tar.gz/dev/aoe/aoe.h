/*-
 * Copyright (c) 2004, Sam Hopkins <sah@coraid.com>
 * Copyright (c) 2006, Stacey D. Son <sds@son.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#ifndef _AOE_H
#define _AOE_H

#include <sys/syslog.h>
#include <sys/bio.h>

#include <sys/taskqueue.h>

#define XPRINTK(L, fmt, arg...) log(L, "aoe:" " %s: " fmt, __func__, ## arg)
#define IPRINTK(fmt, arg...) XPRINTK(LOG_INFO, fmt, ## arg)
#define EPRINTK(fmt, arg...) XPRINTK(LOG_ERR, fmt, ## arg)
#define DPRINTK(fmt, arg...) XPRINTK(LOG_DEBUG, fmt, ## arg)

#define nelem(a) (sizeof (a) / sizeof (a)[0])
#define MINPERMAJ 10
#define AOEMAJOR(unit) ((unit) / MINPERMAJ)
#define AOEMINOR(unit) ((unit) % MINPERMAJ)
#define AOEUNIT(maj, min) ((maj) * MINPERMAJ + (min))
#define WHITESPACE " \t\v\f\n"

#define bio_aoe_baddr bio_driver1
#define bio_aoe_nbuflets bio_driver2

#ifndef ETHERTYPE_AOE
#define ETHERTYPE_AOE 0x88a2
#endif

#ifndef NETISR_AOE
#define NETISR_AOE 19
#endif 

#if (__FreeBSD_version < 600000)
#define ata_ioc_request ata_cmd
#define IOCATAREQUEST IOCATA
#define ata_ioc_request_timeout u.request.timeout
#define ata_ioc_request_ata u.request.u.ata
#define ata_ioc_request_flags u.request.flags
#define ata_ioc_request_data u.request.data
#define ata_ioc_request_count u.request.count
#else
#define ata_ioc_request_timeout timeout
#define ata_ioc_request_ata u.ata
#define ata_ioc_request_flags flags
#define ata_ioc_request_data data
#define ata_ioc_request_count count
#endif

enum {
        AOECMD_ATA,
        AOECMD_CFG,

        AOEFL_RSP = (1<<3),
        AOEFL_ERR = (1<<2),

        AOEAFL_EXT = (1<<6),
        AOEAFL_DEV = (1<<4),
        AOEAFL_ASYNC = (1<<1),
        AOEAFL_WRITE = (1<<0),

        AOECCMD_READ = 0,
        AOECCMD_TEST,
        AOECCMD_PTEST,
        AOECCMD_SET,
        AOECCMD_FSET,

        AOE_HVER = 0x10,
};

struct aoe_hdr {
        u_char ah_dst[6];
        u_char ah_src[6];
        u_short ah_type;
        u_char ah_verfl;
        u_char ah_err;
        u_short ah_major;
        u_char ah_minor;
        u_char ah_cmd;
        u_int ah_tag;
};

struct aoe_atahdr {
        u_char aa_aflags;
        u_char aa_errfeat;
        u_char aa_scnt;
        u_char aa_cmdstat;
        u_char aa_lba0;
        u_char aa_lba1;
        u_char aa_lba2;
        u_char aa_lba3;
        u_char aa_lba4;
        u_char aa_lba5;
        u_char aa_res[2];
};

struct aoe_cfghdr {
	u_short ac_bufcnt;
	u_short ac_fwver;
	u_char ac_scnt;
	u_char ac_aoeccmd;
	u_char ac_cslen[2];
};

enum {	/* this should be in sys/ata.h */
	ATA_SMART = 0xb0,
	ATA_SMART_READ_DATA = 0xd0,
	ATA_SMART_READ_THRESHOLDS = 0xd1,
	ATA_SMART_ATTR_AUTOSAVE = 0xd2,
	ATA_SMART_OFFLINE_IMMEDIATE = 0xd4,
	ATA_SMART_READ_LOG = 0xd5,
	ATA_SMART_WRITE_LOG = 0xd6,
	ATA_SMART_ENABLE = 0xd8,
	ATA_SMART_DISABLE = 0xd9,
	ATA_SMART_STATUS = 0xda,
};

enum {
	DEVFL_UP = 1,	/* device is installed in system and ready for AoE->ATA commands */
	DEVFL_OPEN = (1<<1),
	DEVFL_TKILL = (1<<2),	/* flag for timer to know when to kill self */
	DEVFL_EXT = (1<<3),	/* device accepts lba48 commands */
	DEVFL_CLOSEWAIT = (1<<4), /* device is waiting for close to revalidate */
	DEVFL_TASKON = (1<<5),	/* disk create/destroy task is active */
	DEVFL_WC_UPDATE = (1<<6),	/* This device needs to update write cache status */
	DEVFL_DESTROY = (1<<7),

	MAXATADATA = 1024,	/* max permissable data in frame */
	FREETAG = -1,		/* tag magic; denotes free frame */
	INPROCTAG = -2,		/* tag magic; denotes frame in processing */
	IFLISTSZ = 128,		/* length of the aoe_iflist string */
};

#define AOEHDRSZ (sizeof(struct aoe_hdr) + sizeof(struct aoe_atahdr))

struct ata_ioc_request;
struct callout;
struct g_geom;
struct ifnet;
struct mbuf;
struct mtx;

struct frame {
	int f_tag;
	int f_mlen;
	int f_waited;
	struct bio *f_bp;
	caddr_t f_bioaddr;
	struct mbuf *f_m;
	u_char f_hdr[AOEHDRSZ];
	caddr_t f_data;
};

struct aoedev {
	struct aoedev *ad_next;
	u_char ad_addr[6];
	int ad_flags;
	u_short ad_major;
	u_short ad_minor;


	struct disk *ad_disk;
	struct task ad_task;

	struct ifnet *ad_ifp;
	struct callout ad_callout;
	struct mtx ad_mtx;
	struct bio_queue_head ad_bioq;
	struct bio *ad_inprocess;
	u_long ad_unit;
	off_t ad_nsectors;
	u_short ad_rttavg;
	u_short ad_mintimer;
	u_short ad_lasttag;
	u_long ad_nframes;
	struct frame *ad_frames;
	char ad_ident[512];
};

int aoeblk_register(struct aoedev *);
int aoeblk_unregister(struct aoedev *);

int aoecmd_ata_smart(struct aoedev *, struct ata_ioc_request *);
void aoecmd_work(struct aoedev *d);
void aoecmd_cfg_rsp(struct mbuf *m);
void aoecmd_ata_rsp(struct mbuf *m);
void aoecmd_cfg(u_short, u_char);

struct aoedev *aoedev_set(u_long, char *, struct ifnet *, u_long);
void aoedev_downdev(struct aoedev *);
struct aoedev *aoedev_byaddr(char *);
struct aoedev *aoedev_byunit(u_long);
boolean_t aoedev_busy(void);
void aoedev_freedev(struct aoedev *);
void aoedev_init(void);
void aoedev_exit(void);
void aoedev_wc_update(void);

void aoenet_init(void);
void aoenet_exit(void);
int aoenet_xmitframe(struct aoedev *, struct frame *);
void aoenet_xmitbcast(u_short, u_char);
u_char *aoenet_enaddr(struct ifnet *);
u_int aoenet_maxsize(struct ifnet *);

#endif /* ! _AOE_H */
