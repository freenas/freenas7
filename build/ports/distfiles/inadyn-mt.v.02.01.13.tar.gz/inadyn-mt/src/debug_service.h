#include <stdio.h>
#include "debug_if.h"

#define DBG_SERVICE_PRINTF(msg) os_file_printf msg
#define INFO_PRINTF(msg) os_info_printf msg
#define MAXSTRING 1024
