/*-
 * Copyright (c) 2004, Sam Hopkins <sah@coraid.com>
 * Copyright (c) 2006, Stacey D. Son <sds@son.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $FreeBSD: src/sys/dev/aoe/aoe.c,v 1.23.2.5 2004/09/22 16:50:41 ?? Exp $
 */

/*
 * aoemain.c
 * Module initialization routines, discover timer
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/conf.h>
#include <sys/kernel.h>
#include <sys/lock.h>
#include <sys/module.h>
#include <sys/mutex.h>
#include <sys/sysctl.h>

#include <dev/aoe/aoe.h>

boolean_t aoe_exiting;
static struct callout discover_callout;

SYSCTL_NODE(_net, OID_AUTO, aoe, CTLFLAG_RW, 0, "AoE Driver controllables");

static void
discover_timer(void *vp __unused)
{
	aoecmd_cfg(0xffff, 0xff);
	callout_reset(&discover_callout, hz * 60, discover_timer, NULL); 
}

static int
aoe_loader(struct module *m, int what, void *arg)
{
	switch (what) {
	case MOD_LOAD:
		aoedev_init();
		aoenet_init();
		callout_init(&discover_callout, 1);
		callout_reset(&discover_callout, hz * 60, discover_timer, NULL); 
		IPRINTK("AoE version %d.%d.%d initialized\n", 1, 2, 0);
		return (0);
	case MOD_UNLOAD:
		aoe_exiting = !aoedev_busy();
		if (!aoe_exiting) {
			IPRINTK("can't unload, devices busy\n");
			return (EBUSY);
		}
		callout_stop(&discover_callout);
		aoenet_exit();
		aoedev_exit();

		tsleep(aoe_loader, 0, "aoeunl", hz<<1);

		return (0);
	default:
		return (EINVAL);
	}
}

static moduledata_t aoe_module = {
        "aoe",
        aoe_loader,   
        NULL
};

DECLARE_MODULE(aoe, aoe_module, SI_SUB_DRIVERS, SI_ORDER_MIDDLE);
